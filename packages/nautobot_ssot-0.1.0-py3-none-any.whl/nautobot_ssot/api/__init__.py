"""REST API module for nautobot_ssot plugin."""
